import React from 'react';
import BarChart from '../../pages/LocationDetail/charts/BarChart';
import LineChart from '../../pages/LocationDetail/charts/LineChart';
import PieChart from '../../pages/LocationDetail/charts/PieChart';

const FullScreenModal = ({ chartType, data, color, yAxisLabel, onClose }) => {
  const renderChart = () => {
    switch (chartType) {
      case 'bar':
        return <BarChart data={data} color={color} yAxisLabel={yAxisLabel} />;
      case 'line':
        return <LineChart data={data} />;
      case 'pie':
        return <PieChart data={data} />;
      default:
        return null;
    }
  };

  return (
    <div className="fullscreen-chart-modal">
      <button className="close-fullscreen-btn" onClick={onClose}>
        Close
      </button>
      {renderChart()}
    </div>
  );
};

export default FullScreenModal;