import React from 'react';
import './StatCard.css';

const StatCard = ({ title, value, icon }) => {
  return (
    <div className="stat-card">
      <div className="stat-title">{title}</div>
      <div className={`stat-icon ${title.toLowerCase().includes('generator') ? 'generator-icon' : 'location-icon'}`}>
        {icon}
      </div>
      <div className="stat-value">{value}</div>
    </div>
  );
};

export default StatCard;