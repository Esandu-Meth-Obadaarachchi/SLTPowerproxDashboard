import React from "react";

const MetricsCard = ({ title, metrics }) => {
  return (
    <div className="metrics-card">
      <div className="metrics-header">
        <div className="metrics-header-content">
          <h2 className="metrics-title">{title}</h2>
          <div className="metrics-actions">
            <span className="metrics-icon search-icon"></span>
            <span className="metrics-icon maximize-icon"></span>
          </div>
        </div>
      </div>
      <div className="metrics-content">
        <div className="metrics-grid">
          {metrics.map((metric, index) => (
            <div key={index} className="metric-item">
              <span className="metric-label">{metric.label}</span>
              <div className="metric-value-display">
                {metric.value}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MetricsCard;