import React from "react";

const NumberDisplay = ({ title, value }) => {
  return (
    <div className="number-display-card">
      <div className="number-display-header">
        <h2 className="number-display-title">{title}</h2>
      </div>
      <div className="number-display-content">
        <span className="number-display-value">{value}</span>
      </div>
    </div>
  );
};

export default NumberDisplay;