import React from "react";

const Header = () => {
  return (
    <div className="dashboard-header">
      <div className="header-logo-container">
        <img 
          src="/lovable-uploads/84c28e52-985b-4f10-b5ae-358a6257fff2.png" 
          alt="SLT PowerFree Logo" 
          className="header-logo"
        />
        <h1 className="header-title">Generator Dashboard</h1>
      </div>
      
      <div className="header-controls">
        <div className="header-dropdown">
          <span className="header-dropdown-text">Dash_Gen_HOb2</span>
          <span className="header-dropdown-arrow"></span>
        </div>
        
        <div className="header-time-display">
          <span className="header-time-icon"></span>
          <span>real time - last 1 minutes</span>
        </div>
        
        <button className="header-button">
          <span className="button-icon edit-icon"></span>
          Edit note
        </button>
        
        <button className="header-button">
          <span className="button-icon logout-icon"></span>
          Logout
        </button>
      </div>
    </div>
  );
};

export default Header;