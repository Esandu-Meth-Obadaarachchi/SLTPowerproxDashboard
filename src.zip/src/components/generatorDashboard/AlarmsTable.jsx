import React from "react";

const AlarmsTable = ({ alarms, lastUpdate }) => {
  return (
    <div className="alarms-card">
      <div className="card-header">
        <div className="header-content">
          <h2 className="card-title">Alarms</h2>
          <div className="card-actions">
            <span className="card-icon search-icon"></span>
            <span className="card-icon menu-icon"></span>
            <span className="card-icon maximize-icon"></span>
          </div>
        </div>
        <div className="card-subtitle">
          real time - last day
        </div>
      </div>
      <div className="card-content">
        <table className="alarms-table">
          <thead>
            <tr>
              <th className="checkbox-column">
                <input type="checkbox" className="table-checkbox" />
              </th>
              <th>Time</th>
              <th>Originator</th>
              <th>Type</th>
              <th>Severity</th>
              <th>Status</th>
              <th>Assignee</th>
            </tr>
          </thead>
          <tbody>
            {alarms.map((alarm) => (
              <tr key={alarm.id} className="alarm-row">
                <td>
                  <input type="checkbox" className="table-checkbox" />
                </td>
                <td className="time-cell">{alarm.time}</td>
                <td>{alarm.originator}</td>
                <td>{alarm.type}</td>
                <td className={
                  alarm.severity === "Critical" ? "alarm-critical" :
                  alarm.severity === "High" ? "alarm-high" :
                  alarm.severity === "Medium" ? "alarm-medium" : ""
                }>
                  {alarm.severity}
                </td>
                <td>{alarm.status}</td>
                <td>{alarm.assignee}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AlarmsTable;