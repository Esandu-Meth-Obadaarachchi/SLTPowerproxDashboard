import React from "react";

const FuelGauge = ({ level }) => {
  return (
    <div className="fuel-card">
      <div className="fuel-header">
        <h3 className="fuel-title">Day Tank Fuel Status</h3>
      </div>
      <div className="fuel-content">
        <div className="fuel-gauge">
          <div className="fuel-level" style={{ width: `${level}%` }}></div>
        </div>
        <div className="fuel-percentage">
          {level}%
        </div>
      </div>
    </div>
  );
};

export default FuelGauge;