import React from "react";

const StatusCard = ({ title, value, unit, icon, lastUpdate }) => {
  return (
    <div className="status-card">
      <div className="status-card-content">
        {icon && (
          <div className="status-icon">{icon}</div>
        )}
        <div className="status-info">
          <h3 className="status-title">{title}</h3>
          <div className="status-value-container">
            <span className={title.toLowerCase().includes("temperature") ? "temperature-display" : 
                          title.toLowerCase().includes("pressure") ? "pressure-display" : 
                          "status-value"}>
              {value}
            </span>
            {unit && <span className="status-unit">{unit}</span>}
          </div>
          {lastUpdate && (
            <div className="status-update-time">
              last update {lastUpdate}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StatusCard;