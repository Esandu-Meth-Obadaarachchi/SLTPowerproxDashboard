import React from "react";

const NavigationBar = () => {
  return (
    <div className="navigation-bar">
      <div className="navigation-container">
        <button className="nav-button home-button">
          <span className="nav-icon home-icon"></span>
          Home
        </button>
        <button className="nav-button">
          Voltage & Current Metrics
        </button>
      </div>
    </div>
  );
};

export default NavigationBar;