import React from "react";

const BatteryStatus = ({ voltage, level }) => {
  const isLow = level <= 20;

  return (
    <div className="battery-card">
      <div className="battery-header">
        <h3 className="battery-title">Battery Status</h3>
      </div>
      <div className="battery-content">
        <div className={`battery-container ${isLow ? 'battery-low' : ''}`}>
          <div className="battery-cap"></div>
          <div className="battery-body">
            <div 
              className="battery-level" 
              style={{ height: `${level}%` }}
            ></div>
          </div>
        </div>
        <div className="battery-voltage">
          {voltage}
        </div>
      </div>
    </div>
  );
};

export default BatteryStatus;