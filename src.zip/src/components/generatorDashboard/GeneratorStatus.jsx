import React from "react";

const GeneratorStatus = ({ status, lastUpdate }) => {
  // Determine status color
  const getStatusColor = () => {
    switch (status.toLowerCase()) {
      case "running": return "status-running";
      case "standby": return "status-standby";
      case "stopped": return "status-stopped";
      case "maintenance": return "status-maintenance";
      default: return "status-unknown";
    }
  };

  return (
    <div className="generator-status-card">
      <div className="generator-status-content">
        <div className="generator-status-update">
          last update {lastUpdate}
        </div>
        <div className={`generator-status-value ${getStatusColor()}`}>
          {status}
        </div>
      </div>
    </div>
  );
};

export default GeneratorStatus;