import React from "react";

const Gauge = ({
  title,
  value,
  min,
  max,
  unit,
  color = "#ff9500",
  threshold = 75
}) => {
  // Calculate the rotation angle based on value
  const angle = ((value - min) / (max - min)) * 180 - 90;
  
  // Determine needle color based on threshold
  const needleColor = value > threshold * (max - min) / 100 + min ? "#ff3b30" : color;
  
  // Calculate percentage for the gauge fill
  const percentage = ((value - min) / (max - min)) * 100;

  return (
    <div className="gauge-card">
      <div className="gauge-card-content">
        <div className="gauge-header">
          <div className="gauge-title">{title}</div>
          <button className="gauge-maximize-button">
            <span className="maximize-icon"></span>
          </button>
        </div>
        
        <div className="gauge-container">
          <svg width="100%" height="100%" viewBox="0 0 200 120">
            {/* Gauge background */}
            <path
              d="M10,110 A90,90 0 0,1 190,110"
              fill="none"
              stroke="#eee"
              strokeWidth="20"
              strokeLinecap="round"
            />
            
            {/* Gauge fill */}
            <path
              d="M10,110 A90,90 0 0,1 190,110"
              fill="none"
              stroke={color}
              strokeWidth="20"
              strokeLinecap="round"
              strokeDasharray="282.74"
              strokeDashoffset={282.74 - (282.74 * percentage / 100)}
            />
            
            {/* Tick marks */}
            <g className="tick-marks">
              {[0, 25, 50, 75, 100].map((tick) => {
                const tickAngle = tick * 1.8 - 90;
                const x1 = 100 + 95 * Math.cos((tickAngle * Math.PI) / 180);
                const y1 = 110 + 95 * Math.sin((tickAngle * Math.PI) / 180);
                const x2 = 100 + 85 * Math.cos((tickAngle * Math.PI) / 180);
                const y2 = 110 + 85 * Math.sin((tickAngle * Math.PI) / 180);
                return (
                  <line
                    key={tick}
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke="#888"
                    strokeWidth="2"
                  />
                );
              })}
            </g>
            
            {/* Min and max labels */}
            <text x="10" y="115" fontSize="10" fill="#888">{min}</text>
            <text x="190" y="115" fontSize="10" fill="#888" textAnchor="end">{max}</text>
            
            {/* Needle */}
            <g transform={`rotate(${angle}, 100, 110)`}>
              <line
                x1="100"
                y1="110"
                x2="100"
                y2="40"
                stroke={needleColor}
                strokeWidth="2"
              />
              <circle cx="100" cy="110" r="5" fill={needleColor} />
            </g>
          </svg>
          
          <div className="gauge-value">
            <span className="gauge-value-number">{value}</span>
            <span className="gauge-value-unit">{unit}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Gauge;